<!DOCTYPE html>
<html>
<body style="background-color:black;">

<img src="https://live.staticflickr.com/7310/8921779798_331183395f_b.jpg" >

</body>
</html>